/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.semana2;

/**
 *
 * @author practicantecd
 */
public class CalculadoraBasica extends Calculadora{
        
    private String color;
    
    
    public double resta(double a,double b){
        return a - b;
    }
    
    public double mul(double a,double b){
        return a * b;
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }
}
