package poo.semana2;


public class Calculadora {
    
    private String marca;
    
    
    public double suma(double a,double b){
        return a + b;
    }
    
    public double div(double a,double b){
        return a / b;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    }
