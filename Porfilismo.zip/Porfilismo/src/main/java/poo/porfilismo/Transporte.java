/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.porfilismo;

/**
 *
 * @author practicantecd
 */
public abstract class Transporte {
    private String marca;
    private String modelo;
    
    public abstract void encender(String d);
    
    public String apagar() {
    return "Apagado";
            }
    
    
}
