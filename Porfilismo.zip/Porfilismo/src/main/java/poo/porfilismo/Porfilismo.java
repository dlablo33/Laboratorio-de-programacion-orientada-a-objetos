/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package poo.porfilismo;

/**
 *
 * @author practicantecd
 */
public class Porfilismo {

    public static void main(String[] args) {
        Automovil a=new Automovil();
        
        a.setMarca("Ford");
        System.out.println(a.getMarca());
        a.setModelo("Ka");
        System.out.println(a.encender());
        a.setModelo("Luces Ensendidas");
        System.out.println(a.getModelo());
        a.acelerar();
        a.acelerar(60);
        System.out.println(a.getVelocidad());
        
        
    }
}
