/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.porfilismo;

/**
 *
 * @author practicantecd
 */
public class Automovil extends Transporte {
      
    public void encender(String d){
        System.out.println(d + "Encendido");
    }
    
     private String marca;
    private String modelo;
    private int velocidad;
    private double gasolina;
    private String luces;
 
    public void acelerar(){
        velocidad+=10;
    }
 
    public void acelerar(int v){
        velocidad+=v;
    }
 
    public void frenar(){
        velocidad-=10;
    }
 
    public int getVelocidad(){
        return velocidad;
    }
 
 
 
    public void setMarca(String m){
        marca=m;
    }
 
    public String getMarca (){
        return marca;
    }
 
 
 
    public void imprimirmarca(){
        System.out.println(marca);
    }
 
 
    public String getModelo() {
        return modelo;
    }
 
 
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    

    /**
     * @return the gasolina
     */
    public double getGasolina() {
        return gasolina;
    }

    /**
     * @param gasolina the gasolina to set
     */
    public void setGasolina(double gasolina) {
        this.gasolina = gasolina;
    }

    /**
     * @return the luces
     */
    public String getLuces() {
        return luces;
    }

    /**
     * @param luces the luces to set
     */
    public void setLuces(String luces) {
        this.luces = luces;
    }
    
    
}
