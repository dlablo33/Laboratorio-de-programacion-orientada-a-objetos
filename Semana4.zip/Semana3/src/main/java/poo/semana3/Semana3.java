/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package poo.semana3;

import java.util.Scanner;

/**
 *
 * @author practicantecd
 */
public class Semana3 {

    public static void main(String[] args) {
           Scanner sm = new Scanner(System.in);
    System.out.println("Introducce la marca:");
    String mrca = sm.nextLine();
    
        Scanner mod = new Scanner(System.in);
    System.out.println("Introducce el modelo:");
    String mdl = mod.nextLine();
        
        Calculadora casio = new Calculadora();
    casio.setMarca(mrca);
    System.out.println(casio.getColor());
    casio.setColor(mdl);
    System.out.println(casio.getMarca());
    casio.suma(6.5,9);
    casio.resta(10,4);
    casio.mul(3, 3.4);
    System.out.println("La division es:"+ casio.div(5,5));
    
    }
}
