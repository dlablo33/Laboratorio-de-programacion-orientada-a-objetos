/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package poo.semana3;

/**
 *
 * @author practicantecd
 */
public interface menuconf {
    public String resolconfi();
    public String colorconfi();
    public String sonidoconfi();
}
