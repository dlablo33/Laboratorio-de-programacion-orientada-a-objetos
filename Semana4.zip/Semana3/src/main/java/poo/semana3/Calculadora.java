/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.semana3;

/**
 *
 * @author practicantecd
 */
public class Calculadora extends DispositivoElectronico implements operacionesestandar {
    
    
    public String encender(String d){
        return "Calculadora encendido";
    }
    
    private String marca;      
    private String color;
    
    @Override
    public double suma(double a,double b ){
        return a + b;
    }
    
    @Override
    public double resta(double a,double b){
        return a - b;
    }
    
    
    public double mul(double a,double b){
        return a * b;
    }
    
   
    public double div(double a,double b){
        return a/b;
    }

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return the marca
     */
    public String getMarca() {
        return marca;
    }

    /**
     * @param marca the marca to set
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    @Override
    public void encender() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double suma(double ) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
