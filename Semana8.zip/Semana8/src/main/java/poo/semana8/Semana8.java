/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package poo.semana8;
import java.util.ArrayList;

/**
 *
 * @author practicantecd
 */
public class Semana8 {

    public static void main(String[] args) {
        
        
        ArrayList<transporte> tra = new ArrayList<transporte>();
        
        tra.add(new carro(100,50));
        tra.add(new avion(800,50));
        tra.add(new barco(300,50));
        tra.add(new helicoptero(500,50));
        
        for(transporte tr : tra){
            System.out.println(tr.getClass().toString());
            tr.acelerar();
            tr.encender();
            tr.Luces();
            tr.getMarca();
            tr.getModelo();
            tr.avidrios();
            tr.aLuces();
            tr.vidrios();
         
        }
    }
}
