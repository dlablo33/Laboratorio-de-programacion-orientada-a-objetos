/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.semana8;

/**
 *
 * @author practicantecd
 */
public class barco extends transporte implements siselc{

    public barco(int velocidad, int gas){
    super(velocidad, gas);
}
    
    @Override
    public void encender(){
    System.out.println("La gasolina del automovil es:"+ gas);
            }
    
    
    
    @Override
        public String apagar(){
    System.out.println("Apagar");
        return null;
            }
    
            
            
    @Override
    public String Luces(){
        System.out.println("Encender luces");
        return null;
    }
    
    @Override
        public String aLuces(){
        System.out.println("apagar luces");
        return null;
    }

    @Override
    public String luces() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String aluces() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
        
    
}
