/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo.semana8;

/**
 *
 * @author practicantecd
 */
public abstract class transporte implements siselc{
    public int velocidad,gas;
    private String modelo;
    public String marca;
    
    public transporte(int velocidad,int gas){
        this.velocidad = velocidad;
        this.gas = gas;
    }
    
    public void acelerar(){
        System.out.println("Transporte acelerando"+ velocidad);
    }
    
    public abstract void encender();
    
        public String apagar() {
    return "Dispositivo Apagado";
            }
    
    
        public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    
    
    @Override
            public String avidrios(){
        System.out.println("bajar vidrios");
        return null;
    }
            
        @Override
            public String vidrios(){
        System.out.println("subir vidrios");
        return null;
    }
            
            
    public String Luces(){
        System.out.println("Encender luces");
        return null;
    }
    
        public String aLuces(){
        System.out.println("apagar luces");
        return null;
    }


    
    
}
